A Discord Bot that makes you OP in Inorganic Chemistry
